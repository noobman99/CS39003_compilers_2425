// Testing Function Calls
int add(int x, int y)
{
    return x + y;
}

int main()
{
    int result;
    result = add(3, 4); // Should return 7
    return result;
}