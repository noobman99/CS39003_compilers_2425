// testing array and pointer

int main()
{
    int arr[5];
    int *p = arr;
    return *(p + 2);
}