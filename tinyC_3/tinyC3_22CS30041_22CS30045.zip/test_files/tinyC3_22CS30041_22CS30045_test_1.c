// Testing Basic Expressions
int main()
{
    int a = 5;
    int b = 10;
    int c;

    c = a + b;
    c = a - b;
    c = a * b;
    c = b / a;
    return 0;
}